﻿namespace Tarea_07_Sebas
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblCompletivo = new System.Windows.Forms.Label();
            this.lblExtraordinario = new System.Windows.Forms.Label();
            this.txtnota1 = new System.Windows.Forms.TextBox();
            this.txtnota4 = new System.Windows.Forms.TextBox();
            this.txtnota3 = new System.Windows.Forms.TextBox();
            this.txtnota2 = new System.Windows.Forms.TextBox();
            this.txtCompletivo = new System.Windows.Forms.TextBox();
            this.txtExtraordinario = new System.Windows.Forms.TextBox();
            this.btncal = new System.Windows.Forms.Button();
            this.btnlim = new System.Windows.Forms.Button();
            this.btnsal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(241, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(290, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Registro de Notas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(161, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nota 1:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(417, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(420, 278);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 20);
            this.label4.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(369, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(480, 339);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 20);
            this.label6.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(509, 314);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 20);
            this.label7.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(161, 242);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 25);
            this.label8.TabIndex = 7;
            this.label8.Text = "Nota 4:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(161, 206);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 25);
            this.label9.TabIndex = 8;
            this.label9.Text = "Nota 3:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(161, 166);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 25);
            this.label10.TabIndex = 9;
            this.label10.Text = "Nota 2:";
            // 
            // lblCompletivo
            // 
            this.lblCompletivo.AutoSize = true;
            this.lblCompletivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompletivo.Location = new System.Drawing.Point(156, 310);
            this.lblCompletivo.Name = "lblCompletivo";
            this.lblCompletivo.Size = new System.Drawing.Size(290, 25);
            this.lblCompletivo.TabIndex = 10;
            this.lblCompletivo.Text = "Ingresar nota del completivo:";
            // 
            // lblExtraordinario
            // 
            this.lblExtraordinario.AutoSize = true;
            this.lblExtraordinario.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExtraordinario.Location = new System.Drawing.Point(156, 360);
            this.lblExtraordinario.Name = "lblExtraordinario";
            this.lblExtraordinario.Size = new System.Drawing.Size(319, 25);
            this.lblExtraordinario.TabIndex = 11;
            this.lblExtraordinario.Text = "Ingresar nota del extraordinario:";
            // 
            // txtnota1
            // 
            this.txtnota1.Location = new System.Drawing.Point(237, 128);
            this.txtnota1.Name = "txtnota1";
            this.txtnota1.Size = new System.Drawing.Size(48, 26);
            this.txtnota1.TabIndex = 12;
            // 
            // txtnota4
            // 
            this.txtnota4.Location = new System.Drawing.Point(237, 241);
            this.txtnota4.Name = "txtnota4";
            this.txtnota4.Size = new System.Drawing.Size(48, 26);
            this.txtnota4.TabIndex = 13;
            // 
            // txtnota3
            // 
            this.txtnota3.Location = new System.Drawing.Point(237, 205);
            this.txtnota3.Name = "txtnota3";
            this.txtnota3.Size = new System.Drawing.Size(48, 26);
            this.txtnota3.TabIndex = 14;
            // 
            // txtnota2
            // 
            this.txtnota2.Location = new System.Drawing.Point(237, 167);
            this.txtnota2.Name = "txtnota2";
            this.txtnota2.Size = new System.Drawing.Size(48, 26);
            this.txtnota2.TabIndex = 15;
            // 
            // txtCompletivo
            // 
            this.txtCompletivo.Location = new System.Drawing.Point(450, 309);
            this.txtCompletivo.Name = "txtCompletivo";
            this.txtCompletivo.Size = new System.Drawing.Size(59, 26);
            this.txtCompletivo.TabIndex = 16;
            // 
            // txtExtraordinario
            // 
            this.txtExtraordinario.Location = new System.Drawing.Point(481, 359);
            this.txtExtraordinario.Name = "txtExtraordinario";
            this.txtExtraordinario.Size = new System.Drawing.Size(59, 26);
            this.txtExtraordinario.TabIndex = 17;
            // 
            // btncal
            // 
            this.btncal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncal.Location = new System.Drawing.Point(342, 195);
            this.btncal.Name = "btncal";
            this.btncal.Size = new System.Drawing.Size(114, 47);
            this.btncal.TabIndex = 18;
            this.btncal.Text = "Calcular";
            this.btncal.UseVisualStyleBackColor = true;
            this.btncal.Click += new System.EventHandler(this.btncal_Click);
            // 
            // btnlim
            // 
            this.btnlim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlim.Location = new System.Drawing.Point(472, 196);
            this.btnlim.Name = "btnlim";
            this.btnlim.Size = new System.Drawing.Size(114, 47);
            this.btnlim.TabIndex = 19;
            this.btnlim.Text = "Limpiar";
            this.btnlim.UseVisualStyleBackColor = true;
            this.btnlim.Click += new System.EventHandler(this.btnlim_Click);
            // 
            // btnsal
            // 
            this.btnsal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsal.Location = new System.Drawing.Point(603, 196);
            this.btnsal.Name = "btnsal";
            this.btnsal.Size = new System.Drawing.Size(114, 47);
            this.btnsal.TabIndex = 20;
            this.btnsal.Text = "Salir";
            this.btnsal.UseVisualStyleBackColor = true;
            this.btnsal.Click += new System.EventHandler(this.btnsal_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsal);
            this.Controls.Add(this.btnlim);
            this.Controls.Add(this.btncal);
            this.Controls.Add(this.txtExtraordinario);
            this.Controls.Add(this.txtCompletivo);
            this.Controls.Add(this.txtnota2);
            this.Controls.Add(this.txtnota3);
            this.Controls.Add(this.txtnota4);
            this.Controls.Add(this.txtnota1);
            this.Controls.Add(this.lblExtraordinario);
            this.Controls.Add(this.lblCompletivo);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblCompletivo;
        private System.Windows.Forms.Label lblExtraordinario;
        private System.Windows.Forms.TextBox txtnota1;
        private System.Windows.Forms.TextBox txtnota4;
        private System.Windows.Forms.TextBox txtnota3;
        private System.Windows.Forms.TextBox txtnota2;
        private System.Windows.Forms.TextBox txtCompletivo;
        private System.Windows.Forms.TextBox txtExtraordinario;
        private System.Windows.Forms.Button btncal;
        private System.Windows.Forms.Button btnlim;
        private System.Windows.Forms.Button btnsal;
    }
}

